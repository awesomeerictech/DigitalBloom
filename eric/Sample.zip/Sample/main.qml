import QtQuick
import QtQuick.Window
import QtQuick.Controls
import QtQuick.Layouts
import QtMultimedia
import CodeDecoderVideoSink 1.0

ApplicationWindow
{
    id: window
    visible: true
    width: 640
    height: 480
    title: "Qt QZXing Filter Test"

    CaptureSession {
        camera: Camera {
            active: true
        }
        videoOutput: videoOutput
    }
    VideoOutput{
        id: videoOutput
    }

    CodeDecoderVideoSink{
        videoSink: videoOutput.videoSink
        onTagFound: {
            console.log("Tag found!!!!!", tag)
        }
    }
}